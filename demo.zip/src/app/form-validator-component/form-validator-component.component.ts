import { Component, OnInit } from '@angular/core';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-form-validator-component',
  templateUrl: './form-validator-component.component.html',
  styleUrls: ['./form-validator-component.component.sass']
})
export class FormValidatorComponentComponent implements OnInit {
  // form: FormGroup;
  id: string;
  isAddMode: boolean;
  loading = false;
  submitted = false;
  constructor() { }

  ngOnInit(): void {
  }

  onSubmit() {
    this.submitted = true;


    // stop here if form is invalid
    // if (this.form.invalid) {
    //   return;
    // }

    alert('Form Saved')

  }

}
