import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';
import { Dashboard2Component } from './dashboard2/dashboard2.component';
import { LoginComponent } from './login/login.component'



const routes: Routes = [
  {
    path: 'login', component: LoginComponent
  },

  {
    path: 'dashboard', component: DashboardComponent

  },

  {
    path: 'dashboard2', component: Dashboard2Component

  },

  {
    path: 'home', component: HomeComponent
  },
  
  { path: '**', redirectTo: 'login', pathMatch:"full" }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
