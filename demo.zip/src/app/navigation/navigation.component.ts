import { Component, OnInit } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.scss']
})
export class NavigationComponent implements OnInit {
  events: string[] = [];
  opened_: boolean;

  // opened = true;

  panelExcludedRoutes = ['/login', '/logout', '/'];

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );

  constructor(
    private breakpointObserver: BreakpointObserver,
    public router_: Router,
    private readonly route: ActivatedRoute
  ) { }

  ngOnInit(): void {
  //   console.log(this.route.url)
  //   if (this.panelExcludedRoutes.indexOf(this.router_.url) == -1) {
  //     this.opened = false;
  //   }
  //   else {
  //     this.opened = true;
  //   }
  }

  homeBtn() {
    this.router_.navigate(['/home']);
  }


}
