import { Component, OnInit } from '@angular/core';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import * as Ajv from 'ajv'
// import { compileSchema7 } from './schema7';
@Component({
  selector: 'app-form-validator-component',
  templateUrl: './form-validator-component.component.html',
  styleUrls: ['./form-validator-component.component.sass']
})
export class FormValidatorComponentComponent implements OnInit {
  // form: FormGroup;
  id: string;
  isAddMode: boolean;
  loading = false;
  submitted = false;
  constructor() { }

  ngOnInit(): void {
  }

  onSubmit() {
    this.submitted = true;

    // var Ajv = require('ajv');
    // var ajv = Ajv({ allErrors: true });
    // var valid = ajv.validate(userSchema, userData);
    // if (valid) {
    //   console.log('User data is valid');
    // } else {
    //   console.log('User data is INVALID!');
    //   console.log(ajv.errors);
    // }

    alert('Form Saved')

  }

  // doValidation(data: Object) {
  //   const validate = compileSchema7();

  //   if (validate(data)) {
  //     // data is EvsNavModel here
  //     const text = JSON.stringify(data, undefined, 2);

  //     console.log('Success');
  //   } else {
  //     console.error('Validation had errors...', validate.errors);
  //   }
  // }

}
