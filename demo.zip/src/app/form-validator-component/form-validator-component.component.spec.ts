import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormValidatorComponentComponent } from './form-validator-component.component';

describe('FormValidatorComponentComponent', () => {
  let component: FormValidatorComponentComponent;
  let fixture: ComponentFixture<FormValidatorComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FormValidatorComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FormValidatorComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
