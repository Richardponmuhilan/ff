import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import * as CryptoJS from 'crypto-js';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  public enCryptForm: FormGroup;

  constructor() {
    this.enCryptForm = new FormGroup({
      encryptKey: new FormControl(),//encryption
      inputTextEncrypt: new FormControl(),//encryption

      inputTextDecrypt: new FormControl(),//decryption
      decryptKey: new FormControl()//decryption
    })
  }
  tokenFromUI: string = "";
  encrypted: any = "";
  decrypted: string;
  request: any = "";
  ngOnInit(): void {
  }
  submitEncrypt() {//encryption
    this.tokenFromUI = this.enCryptForm.value.encryptKey;
    if (this.tokenFromUI.length >= 8) {
      this.request = this.enCryptForm.value.inputTextEncrypt;
      this.encryptUsingAES256();
    } else {
      alert('key length should Atleast be 8!')
    }
  }
  encryptUsingAES256() {//encryption
    let _key = CryptoJS.enc.Utf8.parse(this.tokenFromUI);
    let _iv = CryptoJS.enc.Utf8.parse(this.tokenFromUI);
    let encrypted = CryptoJS.AES.encrypt(
      JSON.stringify(this.request), _key, {
      keySize: 16,
      iv: _iv,
      mode: CryptoJS.mode.ECB,
      padding: CryptoJS.pad.Pkcs7
    });
    this.encrypted = encrypted.toString();
  }

  submitDecrypt() {//decryption
    this.tokenFromUI = this.enCryptForm.value.encryptKey;
    this.tokenFromUI = this.enCryptForm.value.encryptKey;
    if (this.tokenFromUI.length >= 8) {
      this.request = this.enCryptForm.value.inputTextDecrypt;
      this.decryptUsingAES256();
    }
    else {
      alert('key length should Atleast be 8!')
    }
  }

  decryptUsingAES256() {//decryption
    let _key = CryptoJS.enc.Utf8.parse(this.tokenFromUI);
    let _iv = CryptoJS.enc.Utf8.parse(this.tokenFromUI);

    this.decrypted = CryptoJS.AES.decrypt(this.request, _key,
      {
        keySize: 16,
        iv: _iv,
        mode: CryptoJS.mode.ECB,
        padding: CryptoJS.pad.Pkcs7
      }).toString(CryptoJS.enc.Utf8);
  }

}
