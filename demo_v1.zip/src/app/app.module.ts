import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
// import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LogincompComponent } from './logincomp/logincomp.component';
// import { FormValidatorComponentComponent } from './form-validator-component/form-validator-component.component';

@NgModule({
  declarations: [
    AppComponent,
    LogincompComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
    // ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
