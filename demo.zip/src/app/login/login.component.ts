import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  

  constructor() { }

  ngOnInit(): void {
  }

  showLog = true;
  showReg = false;
  regBtn() {
    this.showLog = false;
    this.showReg = true;
  }
  logBtn() {
    this.showLog = true;
    this.showReg = false;
  }
  
}
